# Sales Data Cleaning

### About the Dataset
The dataset consists of 11 columns, each column representing an attribute of purchase on a product

***Thus are the listings below:***
- Order ID 
- Product 
- Quantity Ordered 
- Price Each 
- Order Date 
- Purchase Address
- Month, Sales, City, Hour... `Unnecessary and Useless attributes formed with junks`.

### Importing Libraries
##### Activating libraries needed for the analysis and bringing in the data for cleaning 


```python
import pandas as pd
import matplotlib.pyplot as plt

salesdf = pd.read_csv(r'C:\Users\DELL\Downloads\archive (1)\Sales Data.csv')
```


```python
print(plt.style.available)
plt.style.use('classic')
```

    ['Solarize_Light2', '_classic_test_patch', '_mpl-gallery', '_mpl-gallery-nogrid', 'bmh', 'classic', 'dark_background', 'fast', 'fivethirtyeight', 'ggplot', 'grayscale', 'petroff10', 'seaborn-v0_8', 'seaborn-v0_8-bright', 'seaborn-v0_8-colorblind', 'seaborn-v0_8-dark', 'seaborn-v0_8-dark-palette', 'seaborn-v0_8-darkgrid', 'seaborn-v0_8-deep', 'seaborn-v0_8-muted', 'seaborn-v0_8-notebook', 'seaborn-v0_8-paper', 'seaborn-v0_8-pastel', 'seaborn-v0_8-poster', 'seaborn-v0_8-talk', 'seaborn-v0_8-ticks', 'seaborn-v0_8-white', 'seaborn-v0_8-whitegrid', 'tableau-colorblind10']
    

### Let's dive in !!!

        This is where we begin the full analysis and cleaning of the derived data for a retail marketing industry
        Don't give, you have'nt even reach the most interesting part....... Let's go


```python
# salesdf.drop_duplicates(inplace=True)
# salesdf.drop(columns=['Hour','Unnamed: 0'],inplace=True)
```


```python
salesdf['Month'].replace({12:"December", 11:"November"}, inplace=True)
salesdf['Month'].replace({9:"September", 8:"August"}, inplace=True)
salesdf['Month'].replace({6:"June", 5:"May"}, inplace=True)
salesdf['Month'].replace({2:"February", 1:"January"}, inplace=True)
salesdf['Month'].replace({7:"July", 10:"October"}, inplace=True)
salesdf['Month'].replace({3:"March", 4:"April"}, inplace=True)
```


```python

```


```python
salesdf[['Street','City','Zip-Code']] = salesdf['Purchase Address'].str.split(",", expand=True)
```


```python

```


```python
salesdf.drop(columns='Street',inplace=True)
```


```python

```


```python
salesdf[['CCA2','Zip-Code']] = salesdf['Zip-Code'].str.split(expand=True)
```


```python

```


```python
# salesdf.drop(columns='Zip-Code',inplace=True)
```


```python

```


```python
salesdf.rename(columns={'Sales':'$ Sales','Price Each':'Unit Price','Quantity Ordered':'Order Quantity'},inplace=True)
```


```python

```


```python
salesdf
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Order ID</th>
      <th>Product</th>
      <th>Order Quantity</th>
      <th>Unit Price</th>
      <th>Order Date</th>
      <th>Purchase Address</th>
      <th>Month</th>
      <th>$ Sales</th>
      <th>City</th>
      <th>CCA2</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>295665</td>
      <td>Macbook Pro Laptop</td>
      <td>1</td>
      <td>1700.00</td>
      <td>2019-12-30 00:01:00</td>
      <td>136 Church St, New York City, NY 10001</td>
      <td>December</td>
      <td>1700.00</td>
      <td>New York City</td>
      <td>NY</td>
    </tr>
    <tr>
      <th>1</th>
      <td>295666</td>
      <td>LG Washing Machine</td>
      <td>1</td>
      <td>600.00</td>
      <td>2019-12-29 07:03:00</td>
      <td>562 2nd St, New York City, NY 10001</td>
      <td>December</td>
      <td>600.00</td>
      <td>New York City</td>
      <td>NY</td>
    </tr>
    <tr>
      <th>2</th>
      <td>295667</td>
      <td>USB-C Charging Cable</td>
      <td>1</td>
      <td>11.95</td>
      <td>2019-12-12 18:21:00</td>
      <td>277 Main St, New York City, NY 10001</td>
      <td>December</td>
      <td>11.95</td>
      <td>New York City</td>
      <td>NY</td>
    </tr>
    <tr>
      <th>3</th>
      <td>295668</td>
      <td>27in FHD Monitor</td>
      <td>1</td>
      <td>149.99</td>
      <td>2019-12-22 15:13:00</td>
      <td>410 6th St, San Francisco, CA 94016</td>
      <td>December</td>
      <td>149.99</td>
      <td>San Francisco</td>
      <td>CA</td>
    </tr>
    <tr>
      <th>4</th>
      <td>295669</td>
      <td>USB-C Charging Cable</td>
      <td>1</td>
      <td>11.95</td>
      <td>2019-12-18 12:38:00</td>
      <td>43 Hill St, Atlanta, GA 30301</td>
      <td>December</td>
      <td>11.95</td>
      <td>Atlanta</td>
      <td>GA</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>185945</th>
      <td>222905</td>
      <td>AAA Batteries (4-pack)</td>
      <td>1</td>
      <td>2.99</td>
      <td>2019-06-07 19:02:00</td>
      <td>795 Pine St, Boston, MA 02215</td>
      <td>June</td>
      <td>2.99</td>
      <td>Boston</td>
      <td>MA</td>
    </tr>
    <tr>
      <th>185946</th>
      <td>222906</td>
      <td>27in FHD Monitor</td>
      <td>1</td>
      <td>149.99</td>
      <td>2019-06-01 19:29:00</td>
      <td>495 North St, New York City, NY 10001</td>
      <td>June</td>
      <td>149.99</td>
      <td>New York City</td>
      <td>NY</td>
    </tr>
    <tr>
      <th>185947</th>
      <td>222907</td>
      <td>USB-C Charging Cable</td>
      <td>1</td>
      <td>11.95</td>
      <td>2019-06-22 18:57:00</td>
      <td>319 Ridge St, San Francisco, CA 94016</td>
      <td>June</td>
      <td>11.95</td>
      <td>San Francisco</td>
      <td>CA</td>
    </tr>
    <tr>
      <th>185948</th>
      <td>222908</td>
      <td>USB-C Charging Cable</td>
      <td>1</td>
      <td>11.95</td>
      <td>2019-06-26 18:35:00</td>
      <td>916 Main St, San Francisco, CA 94016</td>
      <td>June</td>
      <td>11.95</td>
      <td>San Francisco</td>
      <td>CA</td>
    </tr>
    <tr>
      <th>185949</th>
      <td>222909</td>
      <td>AAA Batteries (4-pack)</td>
      <td>1</td>
      <td>2.99</td>
      <td>2019-06-25 14:33:00</td>
      <td>209 11th St, Atlanta, GA 30301</td>
      <td>June</td>
      <td>2.99</td>
      <td>Atlanta</td>
      <td>GA</td>
    </tr>
  </tbody>
</table>
<p>185950 rows × 10 columns</p>
</div>



### Almost to the end!
    Now, we are now making the cleaned and quick analysed data become an accessible file for me and you and also for futher analysis...
    Don't still give up, this is just the very beginning of the solution process ☺ ....


```python
# salesdf.to_csv(r'C:\Users\DELL\Downloads\archive (1)\Cleaned Sales Data.csv')
```

## 👉 Check this out 👇 
The dataset now consists of 10 columns, each column representing an attribute of purchase on a product, with exactly 185950 rows - crazy 😜 ...

 ***Thus are the new listings below :***

- Order ID - A unique ID for each order placed on each product
- Product - Item that is purchased 
- Order Quantity - Describes how many of that products are ordered
- Unit Price - Price of one of that product purchased
- Order Date - Date on which the order is placed
- Purchase Address - Address to where the order is shipped
- Month - The month in words every order is placed 
- $ Sales - Total sales of every quantity of product purchased 
- City - City in which every product is ordered from
- CCA2 - Country in which each product are purchased (In Abbreviation)

### That's not still the end 
**Let's begin the exploration of the cleaned data ☺**

At first check out the bringing of the data again after final rearrangement and restructuring in `MICROSOFT EXCEL` for full Exploratory Data Analysis


```python

```


```python
 salesdata = pd.read_csv(r'C:\Users\DELL\Downloads\archive (1)\Cleaned Sales Data.csv')
```


```python
salesdata.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Order ID</th>
      <th>Order Quantity</th>
      <th>Unit Price</th>
      <th>$ Sales</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>185950.000000</td>
      <td>185950.000000</td>
      <td>185950.000000</td>
      <td>185950.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>230417.569379</td>
      <td>1.124383</td>
      <td>184.399735</td>
      <td>185.490917</td>
    </tr>
    <tr>
      <th>std</th>
      <td>51512.737110</td>
      <td>0.442793</td>
      <td>332.731330</td>
      <td>332.919771</td>
    </tr>
    <tr>
      <th>min</th>
      <td>141234.000000</td>
      <td>1.000000</td>
      <td>2.990000</td>
      <td>2.990000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>185831.250000</td>
      <td>1.000000</td>
      <td>11.950000</td>
      <td>11.950000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>230367.500000</td>
      <td>1.000000</td>
      <td>14.950000</td>
      <td>14.950000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>275035.750000</td>
      <td>1.000000</td>
      <td>150.000000</td>
      <td>150.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>319670.000000</td>
      <td>9.000000</td>
      <td>1700.000000</td>
      <td>3400.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
groups1 = salesdata.groupby(['City'], as_index=False).agg({'Order ID':'count','Order Quantity':'count','$ Sales':['sum']})
```


```python
groups1.sort_values(by = 'City',ascending=False)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead tr th {
        text-align: left;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr>
      <th></th>
      <th>City</th>
      <th>Order ID</th>
      <th>Order Quantity</th>
      <th>$ Sales</th>
    </tr>
    <tr>
      <th></th>
      <th></th>
      <th>count</th>
      <th>count</th>
      <th>sum</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>8</th>
      <td>Seattle</td>
      <td>14732</td>
      <td>14732</td>
      <td>2747755.48</td>
    </tr>
    <tr>
      <th>7</th>
      <td>San Francisco</td>
      <td>44732</td>
      <td>44732</td>
      <td>8262203.91</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Portland</td>
      <td>12465</td>
      <td>12465</td>
      <td>2320490.61</td>
    </tr>
    <tr>
      <th>5</th>
      <td>New York City</td>
      <td>24876</td>
      <td>24876</td>
      <td>4664317.43</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Los Angeles</td>
      <td>29605</td>
      <td>29605</td>
      <td>5452570.80</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Dallas</td>
      <td>14820</td>
      <td>14820</td>
      <td>2767975.40</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Boston</td>
      <td>19934</td>
      <td>19934</td>
      <td>3661642.01</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Austin</td>
      <td>9905</td>
      <td>9905</td>
      <td>1819581.75</td>
    </tr>
    <tr>
      <th>0</th>
      <td>Atlanta</td>
      <td>14881</td>
      <td>14881</td>
      <td>2795498.58</td>
    </tr>
  </tbody>
</table>
</div>



    This above shows all the city in which product-orders are placed, it show case the sum of total orders taken in every city, and the number of  
    orders taken which are is derived by the orderID, analytically said to be unique for all order.

*POINTS*

1. The city - `Los Angeles` settles to be the city products are highly ordered
2. Much sales are made in this same `Los Angeles` hopefully because orders were placed from there than any other relevant city
3. Much customers are not really from `Austin`, for this reason it came out as the lowest-city in order-count which also reflect in its 
product total sale for the whole year - `2019`


```python
plotter = salesdata[salesdata['Unit Price']>1].head().sort_values(by='Unit Price',ascending=False)

plotter
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Order ID</th>
      <th>Product</th>
      <th>Order Quantity</th>
      <th>Unit Price</th>
      <th>$ Sales</th>
      <th>Order Date</th>
      <th>Month</th>
      <th>Purchase Address</th>
      <th>City</th>
      <th>CCA2</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>295665</td>
      <td>Macbook Pro Laptop</td>
      <td>1</td>
      <td>1700.00</td>
      <td>1700.00</td>
      <td>12/30/2019 0:01</td>
      <td>December</td>
      <td>136 Church St, New York City, NY 10001</td>
      <td>New York City</td>
      <td>NY</td>
    </tr>
    <tr>
      <th>1</th>
      <td>295666</td>
      <td>LG Washing Machine</td>
      <td>1</td>
      <td>600.00</td>
      <td>600.00</td>
      <td>12/29/2019 7:03</td>
      <td>December</td>
      <td>562 2nd St, New York City, NY 10001</td>
      <td>New York City</td>
      <td>NY</td>
    </tr>
    <tr>
      <th>3</th>
      <td>295668</td>
      <td>27in FHD Monitor</td>
      <td>1</td>
      <td>149.99</td>
      <td>149.99</td>
      <td>12/22/2019 15:13</td>
      <td>December</td>
      <td>410 6th St, San Francisco, CA 94016</td>
      <td>San Francisco</td>
      <td>CA</td>
    </tr>
    <tr>
      <th>2</th>
      <td>295667</td>
      <td>USB-C Charging Cable</td>
      <td>1</td>
      <td>11.95</td>
      <td>11.95</td>
      <td>12/12/2019 18:21</td>
      <td>December</td>
      <td>277 Main St, New York City, NY 10001</td>
      <td>New York City</td>
      <td>NY</td>
    </tr>
    <tr>
      <th>4</th>
      <td>295669</td>
      <td>USB-C Charging Cable</td>
      <td>1</td>
      <td>11.95</td>
      <td>11.95</td>
      <td>12/18/2019 12:38</td>
      <td>December</td>
      <td>43 Hill St, Atlanta, GA 30301</td>
      <td>Atlanta</td>
      <td>GA</td>
    </tr>
  </tbody>
</table>
</div>




```python
plotter[['Product','Unit Price']].plot.barh(x = 'Product', color = 'Green', xlabel = 'Unit Price', figsize = (10,4))
```




    <Axes: xlabel='Unit Price', ylabel='Product'>




    
![png](output_31_1.png)
    


        This above 👆👆 also show the details of the top five products with high cost, sold for the year - 2019
- This make known of `Macbook Pro Laptop` as the product sold at the highest cost for the year sales - 2019

        As you can also see below this 👇 is another `DataFrame` showing five products with low cost, sold for the year sales- 2019
- This also expose `AAA Batteries (4-pack)` as the product sold at the lowest cost for the year sales - 2019 


```python
salesdata[salesdata['Unit Price']<1000].tail().sort_values('Unit Price')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Order ID</th>
      <th>Product</th>
      <th>Order Quantity</th>
      <th>Unit Price</th>
      <th>$ Sales</th>
      <th>Order Date</th>
      <th>Month</th>
      <th>Purchase Address</th>
      <th>City</th>
      <th>CCA2</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>185945</th>
      <td>222905</td>
      <td>AAA Batteries (4-pack)</td>
      <td>1</td>
      <td>2.99</td>
      <td>2.99</td>
      <td>6/7/2019 19:02</td>
      <td>June</td>
      <td>795 Pine St, Boston, MA 02215</td>
      <td>Boston</td>
      <td>MA</td>
    </tr>
    <tr>
      <th>185949</th>
      <td>222909</td>
      <td>AAA Batteries (4-pack)</td>
      <td>1</td>
      <td>2.99</td>
      <td>2.99</td>
      <td>6/25/2019 14:33</td>
      <td>June</td>
      <td>209 11th St, Atlanta, GA 30301</td>
      <td>Atlanta</td>
      <td>GA</td>
    </tr>
    <tr>
      <th>185947</th>
      <td>222907</td>
      <td>USB-C Charging Cable</td>
      <td>1</td>
      <td>11.95</td>
      <td>11.95</td>
      <td>6/22/2019 18:57</td>
      <td>June</td>
      <td>319 Ridge St, San Francisco, CA 94016</td>
      <td>San Francisco</td>
      <td>CA</td>
    </tr>
    <tr>
      <th>185948</th>
      <td>222908</td>
      <td>USB-C Charging Cable</td>
      <td>1</td>
      <td>11.95</td>
      <td>11.95</td>
      <td>6/26/2019 18:35</td>
      <td>June</td>
      <td>916 Main St, San Francisco, CA 94016</td>
      <td>San Francisco</td>
      <td>CA</td>
    </tr>
    <tr>
      <th>185946</th>
      <td>222906</td>
      <td>27in FHD Monitor</td>
      <td>1</td>
      <td>149.99</td>
      <td>149.99</td>
      <td>6/1/2019 19:29</td>
      <td>June</td>
      <td>495 North St, New York City, NY 10001</td>
      <td>New York City</td>
      <td>NY</td>
    </tr>
  </tbody>
</table>
</div>



### Neexxtt
This is so funny that the highest product sold in every month, like every month of 2019 is `iPhone` mehhnn people dey buy i phone oo, wetin we dey wait for. I'm very sure you're not also using one 😂😂😂

**Check and explore below 👇👇...**

- Out of all these months of the sales in year 2019, highest sales revenue is generated from `December` with the sum of dollars `4,613,443.34`..
- Even in this month and other `iPhone` are the good sold the most

  I will like us to check exactly how much they sold the product `iPhone` for it to be the product sold the most in every month... Check with me ☺ ☺


```python
salesdata.groupby('Month').agg({'$ Sales':'sum','Product':['count','max']})
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead tr th {
        text-align: left;
    }

    .dataframe thead tr:last-of-type th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr>
      <th></th>
      <th>$ Sales</th>
      <th colspan="2" halign="left">Product</th>
    </tr>
    <tr>
      <th></th>
      <th>sum</th>
      <th>count</th>
      <th>max</th>
    </tr>
    <tr>
      <th>Month</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>April</th>
      <td>3390670.24</td>
      <td>18279</td>
      <td>iPhone</td>
    </tr>
    <tr>
      <th>August</th>
      <td>2244467.88</td>
      <td>11961</td>
      <td>iPhone</td>
    </tr>
    <tr>
      <th>December</th>
      <td>4613443.34</td>
      <td>24984</td>
      <td>iPhone</td>
    </tr>
    <tr>
      <th>February</th>
      <td>2202022.42</td>
      <td>11975</td>
      <td>iPhone</td>
    </tr>
    <tr>
      <th>January</th>
      <td>1822256.73</td>
      <td>9709</td>
      <td>iPhone</td>
    </tr>
    <tr>
      <th>July</th>
      <td>2647775.76</td>
      <td>14293</td>
      <td>iPhone</td>
    </tr>
    <tr>
      <th>June</th>
      <td>2577802.26</td>
      <td>13554</td>
      <td>iPhone</td>
    </tr>
    <tr>
      <th>March</th>
      <td>2807100.38</td>
      <td>15153</td>
      <td>iPhone</td>
    </tr>
    <tr>
      <th>May</th>
      <td>3152606.75</td>
      <td>16566</td>
      <td>iPhone</td>
    </tr>
    <tr>
      <th>November</th>
      <td>3199603.20</td>
      <td>17573</td>
      <td>iPhone</td>
    </tr>
    <tr>
      <th>October</th>
      <td>3736726.88</td>
      <td>20282</td>
      <td>iPhone</td>
    </tr>
    <tr>
      <th>September</th>
      <td>2097560.13</td>
      <td>11621</td>
      <td>iPhone</td>
    </tr>
  </tbody>
</table>
</div>




```python
apple = salesdata[['Product','Order Quantity','Unit Price','$ Sales']]

apple[apple['Product'].str.contains('iPhone')].sort_values(by='Order Quantity', ascending=False).head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Product</th>
      <th>Order Quantity</th>
      <th>Unit Price</th>
      <th>$ Sales</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>36901</th>
      <td>iPhone</td>
      <td>2</td>
      <td>700.0</td>
      <td>1400.0</td>
    </tr>
    <tr>
      <th>160387</th>
      <td>iPhone</td>
      <td>2</td>
      <td>700.0</td>
      <td>1400.0</td>
    </tr>
    <tr>
      <th>126563</th>
      <td>iPhone</td>
      <td>2</td>
      <td>700.0</td>
      <td>1400.0</td>
    </tr>
    <tr>
      <th>41376</th>
      <td>iPhone</td>
      <td>2</td>
      <td>700.0</td>
      <td>1400.0</td>
    </tr>
    <tr>
      <th>63897</th>
      <td>iPhone</td>
      <td>2</td>
      <td>700.0</td>
      <td>1400.0</td>
    </tr>
  </tbody>
</table>
</div>



### Yh is this not want you want?? 
    If you want to buy, go and buy, iPhone is just 700.0 dollars 😔😔😔

#### Let's move on!


```python
salesdata_description = salesdata[['Product','Unit Price','$ Sales']].groupby('Product').describe()
salesdata_description
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead tr th {
        text-align: left;
    }

    .dataframe thead tr:last-of-type th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr>
      <th></th>
      <th colspan="8" halign="left">Unit Price</th>
      <th colspan="8" halign="left">$ Sales</th>
    </tr>
    <tr>
      <th></th>
      <th>count</th>
      <th>mean</th>
      <th>std</th>
      <th>min</th>
      <th>25%</th>
      <th>50%</th>
      <th>75%</th>
      <th>max</th>
      <th>count</th>
      <th>mean</th>
      <th>std</th>
      <th>min</th>
      <th>25%</th>
      <th>50%</th>
      <th>75%</th>
      <th>max</th>
    </tr>
    <tr>
      <th>Product</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>20in Monitor</th>
      <td>4101.0</td>
      <td>109.99</td>
      <td>5.926649e-12</td>
      <td>109.99</td>
      <td>109.99</td>
      <td>109.99</td>
      <td>109.99</td>
      <td>109.99</td>
      <td>4101.0</td>
      <td>110.740968</td>
      <td>9.058423</td>
      <td>109.99</td>
      <td>109.99</td>
      <td>109.99</td>
      <td>109.99</td>
      <td>219.98</td>
    </tr>
    <tr>
      <th>27in 4K Gaming Monitor</th>
      <td>6230.0</td>
      <td>389.99</td>
      <td>2.319398e-11</td>
      <td>389.99</td>
      <td>389.99</td>
      <td>389.99</td>
      <td>389.99</td>
      <td>389.99</td>
      <td>6230.0</td>
      <td>390.866382</td>
      <td>18.467997</td>
      <td>389.99</td>
      <td>389.99</td>
      <td>389.99</td>
      <td>389.99</td>
      <td>779.98</td>
    </tr>
    <tr>
      <th>27in FHD Monitor</th>
      <td>7507.0</td>
      <td>149.99</td>
      <td>7.958609e-12</td>
      <td>149.99</td>
      <td>149.99</td>
      <td>149.99</td>
      <td>149.99</td>
      <td>149.99</td>
      <td>7507.0</td>
      <td>150.849141</td>
      <td>11.319959</td>
      <td>149.99</td>
      <td>149.99</td>
      <td>149.99</td>
      <td>149.99</td>
      <td>299.98</td>
    </tr>
    <tr>
      <th>34in Ultrawide Monitor</th>
      <td>6181.0</td>
      <td>379.99</td>
      <td>1.631538e-11</td>
      <td>379.99</td>
      <td>379.99</td>
      <td>379.99</td>
      <td>379.99</td>
      <td>379.99</td>
      <td>6181.0</td>
      <td>381.096588</td>
      <td>20.477687</td>
      <td>379.99</td>
      <td>379.99</td>
      <td>379.99</td>
      <td>379.99</td>
      <td>759.98</td>
    </tr>
    <tr>
      <th>AA Batteries (4-pack)</th>
      <td>20577.0</td>
      <td>3.84</td>
      <td>1.988236e-12</td>
      <td>3.84</td>
      <td>3.84</td>
      <td>3.84</td>
      <td>3.84</td>
      <td>3.84</td>
      <td>20577.0</td>
      <td>5.157137</td>
      <td>2.596991</td>
      <td>3.84</td>
      <td>3.84</td>
      <td>3.84</td>
      <td>7.68</td>
      <td>26.88</td>
    </tr>
    <tr>
      <th>AAA Batteries (4-pack)</th>
      <td>20641.0</td>
      <td>2.99</td>
      <td>5.813269e-13</td>
      <td>2.99</td>
      <td>2.99</td>
      <td>2.99</td>
      <td>2.99</td>
      <td>2.99</td>
      <td>20641.0</td>
      <td>4.493040</td>
      <td>2.599275</td>
      <td>2.99</td>
      <td>2.99</td>
      <td>2.99</td>
      <td>5.98</td>
      <td>26.91</td>
    </tr>
    <tr>
      <th>Apple Airpods Headphones</th>
      <td>15549.0</td>
      <td>150.00</td>
      <td>0.000000e+00</td>
      <td>150.00</td>
      <td>150.00</td>
      <td>150.00</td>
      <td>150.00</td>
      <td>150.00</td>
      <td>15549.0</td>
      <td>151.080455</td>
      <td>12.798653</td>
      <td>150.00</td>
      <td>150.00</td>
      <td>150.00</td>
      <td>150.00</td>
      <td>450.00</td>
    </tr>
    <tr>
      <th>Bose SoundSport Headphones</th>
      <td>13325.0</td>
      <td>99.99</td>
      <td>8.157337e-12</td>
      <td>99.99</td>
      <td>99.99</td>
      <td>99.99</td>
      <td>99.99</td>
      <td>99.99</td>
      <td>13325.0</td>
      <td>100.980520</td>
      <td>10.053349</td>
      <td>99.99</td>
      <td>99.99</td>
      <td>99.99</td>
      <td>99.99</td>
      <td>299.97</td>
    </tr>
    <tr>
      <th>Flatscreen TV</th>
      <td>4800.0</td>
      <td>300.00</td>
      <td>0.000000e+00</td>
      <td>300.00</td>
      <td>300.00</td>
      <td>300.00</td>
      <td>300.00</td>
      <td>300.00</td>
      <td>4800.0</td>
      <td>301.187500</td>
      <td>18.839156</td>
      <td>300.00</td>
      <td>300.00</td>
      <td>300.00</td>
      <td>300.00</td>
      <td>600.00</td>
    </tr>
    <tr>
      <th>Google Phone</th>
      <td>5525.0</td>
      <td>600.00</td>
      <td>0.000000e+00</td>
      <td>600.00</td>
      <td>600.00</td>
      <td>600.00</td>
      <td>600.00</td>
      <td>600.00</td>
      <td>5525.0</td>
      <td>600.760181</td>
      <td>21.345097</td>
      <td>600.00</td>
      <td>600.00</td>
      <td>600.00</td>
      <td>600.00</td>
      <td>1200.00</td>
    </tr>
    <tr>
      <th>LG Dryer</th>
      <td>646.0</td>
      <td>600.00</td>
      <td>0.000000e+00</td>
      <td>600.00</td>
      <td>600.00</td>
      <td>600.00</td>
      <td>600.00</td>
      <td>600.00</td>
      <td>646.0</td>
      <td>600.000000</td>
      <td>0.000000</td>
      <td>600.00</td>
      <td>600.00</td>
      <td>600.00</td>
      <td>600.00</td>
      <td>600.00</td>
    </tr>
    <tr>
      <th>LG Washing Machine</th>
      <td>666.0</td>
      <td>600.00</td>
      <td>0.000000e+00</td>
      <td>600.00</td>
      <td>600.00</td>
      <td>600.00</td>
      <td>600.00</td>
      <td>600.00</td>
      <td>666.0</td>
      <td>600.000000</td>
      <td>0.000000</td>
      <td>600.00</td>
      <td>600.00</td>
      <td>600.00</td>
      <td>600.00</td>
      <td>600.00</td>
    </tr>
    <tr>
      <th>Lightning Charging Cable</th>
      <td>21658.0</td>
      <td>14.95</td>
      <td>6.098374e-12</td>
      <td>14.95</td>
      <td>14.95</td>
      <td>14.95</td>
      <td>14.95</td>
      <td>14.95</td>
      <td>21658.0</td>
      <td>16.026140</td>
      <td>4.167308</td>
      <td>14.95</td>
      <td>14.95</td>
      <td>14.95</td>
      <td>14.95</td>
      <td>59.80</td>
    </tr>
    <tr>
      <th>Macbook Pro Laptop</th>
      <td>4724.0</td>
      <td>1700.00</td>
      <td>0.000000e+00</td>
      <td>1700.00</td>
      <td>1700.00</td>
      <td>1700.00</td>
      <td>1700.00</td>
      <td>1700.00</td>
      <td>4724.0</td>
      <td>1701.439458</td>
      <td>49.452244</td>
      <td>1700.00</td>
      <td>1700.00</td>
      <td>1700.00</td>
      <td>1700.00</td>
      <td>3400.00</td>
    </tr>
    <tr>
      <th>ThinkPad Laptop</th>
      <td>4128.0</td>
      <td>999.99</td>
      <td>1.056279e-10</td>
      <td>999.99</td>
      <td>999.99</td>
      <td>999.99</td>
      <td>999.99</td>
      <td>999.99</td>
      <td>4128.0</td>
      <td>1000.474491</td>
      <td>22.008386</td>
      <td>999.99</td>
      <td>999.99</td>
      <td>999.99</td>
      <td>999.99</td>
      <td>1999.98</td>
    </tr>
    <tr>
      <th>USB-C Charging Cable</th>
      <td>21903.0</td>
      <td>11.95</td>
      <td>4.783838e-12</td>
      <td>11.95</td>
      <td>11.95</td>
      <td>11.95</td>
      <td>11.95</td>
      <td>11.95</td>
      <td>21903.0</td>
      <td>13.080457</td>
      <td>3.867425</td>
      <td>11.95</td>
      <td>11.95</td>
      <td>11.95</td>
      <td>11.95</td>
      <td>71.70</td>
    </tr>
    <tr>
      <th>Vareebadd Phone</th>
      <td>2065.0</td>
      <td>400.00</td>
      <td>0.000000e+00</td>
      <td>400.00</td>
      <td>400.00</td>
      <td>400.00</td>
      <td>400.00</td>
      <td>400.00</td>
      <td>2065.0</td>
      <td>400.581114</td>
      <td>15.238776</td>
      <td>400.00</td>
      <td>400.00</td>
      <td>400.00</td>
      <td>400.00</td>
      <td>800.00</td>
    </tr>
    <tr>
      <th>Wired Headphones</th>
      <td>18882.0</td>
      <td>11.99</td>
      <td>2.597102e-12</td>
      <td>11.99</td>
      <td>11.99</td>
      <td>11.99</td>
      <td>11.99</td>
      <td>11.99</td>
      <td>18882.0</td>
      <td>13.053619</td>
      <td>3.763668</td>
      <td>11.99</td>
      <td>11.99</td>
      <td>11.99</td>
      <td>11.99</td>
      <td>47.96</td>
    </tr>
    <tr>
      <th>iPhone</th>
      <td>6842.0</td>
      <td>700.00</td>
      <td>0.000000e+00</td>
      <td>700.00</td>
      <td>700.00</td>
      <td>700.00</td>
      <td>700.00</td>
      <td>700.00</td>
      <td>6842.0</td>
      <td>700.716165</td>
      <td>22.380253</td>
      <td>700.00</td>
      <td>700.00</td>
      <td>700.00</td>
      <td>700.00</td>
      <td>1400.00</td>
    </tr>
  </tbody>
</table>
</div>




```python
salesdata_description.plot.hist(figsize=(20,5))
```




    <Axes: ylabel='Frequency'>




    
![png](output_39_1.png)
    



```python
salesdata
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Order ID</th>
      <th>Product</th>
      <th>Order Quantity</th>
      <th>Unit Price</th>
      <th>$ Sales</th>
      <th>Order Date</th>
      <th>Month</th>
      <th>Purchase Address</th>
      <th>City</th>
      <th>CCA2</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>295665</td>
      <td>Macbook Pro Laptop</td>
      <td>1</td>
      <td>1700.00</td>
      <td>1700.00</td>
      <td>12/30/2019 0:01</td>
      <td>December</td>
      <td>136 Church St, New York City, NY 10001</td>
      <td>New York City</td>
      <td>NY</td>
    </tr>
    <tr>
      <th>1</th>
      <td>295666</td>
      <td>LG Washing Machine</td>
      <td>1</td>
      <td>600.00</td>
      <td>600.00</td>
      <td>12/29/2019 7:03</td>
      <td>December</td>
      <td>562 2nd St, New York City, NY 10001</td>
      <td>New York City</td>
      <td>NY</td>
    </tr>
    <tr>
      <th>2</th>
      <td>295667</td>
      <td>USB-C Charging Cable</td>
      <td>1</td>
      <td>11.95</td>
      <td>11.95</td>
      <td>12/12/2019 18:21</td>
      <td>December</td>
      <td>277 Main St, New York City, NY 10001</td>
      <td>New York City</td>
      <td>NY</td>
    </tr>
    <tr>
      <th>3</th>
      <td>295668</td>
      <td>27in FHD Monitor</td>
      <td>1</td>
      <td>149.99</td>
      <td>149.99</td>
      <td>12/22/2019 15:13</td>
      <td>December</td>
      <td>410 6th St, San Francisco, CA 94016</td>
      <td>San Francisco</td>
      <td>CA</td>
    </tr>
    <tr>
      <th>4</th>
      <td>295669</td>
      <td>USB-C Charging Cable</td>
      <td>1</td>
      <td>11.95</td>
      <td>11.95</td>
      <td>12/18/2019 12:38</td>
      <td>December</td>
      <td>43 Hill St, Atlanta, GA 30301</td>
      <td>Atlanta</td>
      <td>GA</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>185945</th>
      <td>222905</td>
      <td>AAA Batteries (4-pack)</td>
      <td>1</td>
      <td>2.99</td>
      <td>2.99</td>
      <td>6/7/2019 19:02</td>
      <td>June</td>
      <td>795 Pine St, Boston, MA 02215</td>
      <td>Boston</td>
      <td>MA</td>
    </tr>
    <tr>
      <th>185946</th>
      <td>222906</td>
      <td>27in FHD Monitor</td>
      <td>1</td>
      <td>149.99</td>
      <td>149.99</td>
      <td>6/1/2019 19:29</td>
      <td>June</td>
      <td>495 North St, New York City, NY 10001</td>
      <td>New York City</td>
      <td>NY</td>
    </tr>
    <tr>
      <th>185947</th>
      <td>222907</td>
      <td>USB-C Charging Cable</td>
      <td>1</td>
      <td>11.95</td>
      <td>11.95</td>
      <td>6/22/2019 18:57</td>
      <td>June</td>
      <td>319 Ridge St, San Francisco, CA 94016</td>
      <td>San Francisco</td>
      <td>CA</td>
    </tr>
    <tr>
      <th>185948</th>
      <td>222908</td>
      <td>USB-C Charging Cable</td>
      <td>1</td>
      <td>11.95</td>
      <td>11.95</td>
      <td>6/26/2019 18:35</td>
      <td>June</td>
      <td>916 Main St, San Francisco, CA 94016</td>
      <td>San Francisco</td>
      <td>CA</td>
    </tr>
    <tr>
      <th>185949</th>
      <td>222909</td>
      <td>AAA Batteries (4-pack)</td>
      <td>1</td>
      <td>2.99</td>
      <td>2.99</td>
      <td>6/25/2019 14:33</td>
      <td>June</td>
      <td>209 11th St, Atlanta, GA 30301</td>
      <td>Atlanta</td>
      <td>GA</td>
    </tr>
  </tbody>
</table>
<p>185950 rows × 10 columns</p>
</div>



### 🔚Finally🧠 

**Now this is the ending part of all what we've done together....... This is a project that focuses on analyzing retail sales data to uncover business insights that can support decision-making. Using Python and Pandas, and Matplotlib, I performed data cleaning, validation, and exploratory data analysis. I then created an interactive Tableau dashboard to visualize sales trends, product performance, regional performance, and profitability metrics which you have not even seen at all, just chill because it's on the way - Tableau Dashboard**

**Key outcomes included identifying top-performing product categories, high-revenue regions, seasonal sales trends, and opportunities for improving business performance.
Thank for the time you've used in exploring and going through this with me dilligently and if na sey you just jump come ending God dey see you😂😂😂**

    Much Love ♥♥♥ Enjoy!


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```
